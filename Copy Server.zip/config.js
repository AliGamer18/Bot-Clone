module.exports={
    probot_ids :'',//أيدي بروبوت
    recipientId : '',//أيدي الشخص ألي يتحول له الكريدت عندا نسخ السيرفر
    price : '',//سعر النسخ
    serverid : '',//أيدي سيرفارك
    token : ''//توكن بوتك
}
